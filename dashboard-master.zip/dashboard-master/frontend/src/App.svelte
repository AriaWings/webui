<Router {routes} />

<script>
    import { Router } from 'svelte-router-spa'
    import { routes } from './routes'
</script>
