<Badge>
  <div class="inner">
    <i class="fas fa-gem"></i>
    <span>Premium</span>
  </div>
</Badge>

<script>
    import Badge from "./Badge.svelte";
</script>

<style>
  .inner {
      display: flex;
      flex-direction: row;
      align-items: center;
      gap: 4px;
  }
</style>