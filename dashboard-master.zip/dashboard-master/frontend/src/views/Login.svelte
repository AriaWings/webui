<script>
  import {redirectLogin} from '../includes/Auth.svelte'

  redirectLogin()
</script>