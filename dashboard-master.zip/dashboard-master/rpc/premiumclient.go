package rpc

import "github.com/TicketsBot/common/premium"

var PremiumClient premium.IPremiumLookupClient
