package utils

import "github.com/TicketsBot/archiverclient"

var ArchiverClient *archiverclient.ArchiverClient
