package utils

import (
	"github.com/TicketsBot/common/secureproxy"
)

var SecureProxyClient *secureproxy.Client
